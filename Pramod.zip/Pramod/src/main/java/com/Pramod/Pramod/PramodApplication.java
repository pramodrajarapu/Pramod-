package com.Pramod.Pramod;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PramodApplication {

	public static void main(String[] args) {
		SpringApplication.run(PramodApplication.class, args);
	}

}
